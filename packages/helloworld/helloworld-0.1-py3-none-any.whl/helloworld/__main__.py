from . import __author__

if __name__ == '__main__':
    f'''
    {__author__} will be very happy to see you here!
    '''
    print("Hello World!")