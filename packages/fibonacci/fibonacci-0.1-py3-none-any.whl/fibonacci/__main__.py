from itertools import takewhile
import sys

from . import __author__
from . import fibonacci


if __name__ == '__main__':
    f'''
    {__author__} will be very happy to see you here!
    '''
    n = int(sys.argv[1]) if len(sys.argv) > 1 else 0
    fib = fibonacci()
    for item in takewhile(lambda pairs: pairs[0] < n, enumerate(fib)):
        print(item[1])